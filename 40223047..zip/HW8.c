#include <stdio.h>
struct time
{ 
  int min;
  int sec;  
};
struct runner
{
  char firstname[25];
  char lastname[25];
  char ID[10];
  struct time *record;
  struct time runningTime;
};
int main()
{
 int racer,R,T,S,Y,j;
  printf("enter nums of racers:\n");
   scanf("%d",&racer);
 struct runner r[racer];
  for(int i;i<racer;i++)
   scanf("%s %s %s %d %d %d %d",&r[i].firstname,&r[i].lastname,&r[i].ID,
   (*r).record->min,(*r).record->sec,&r[i].runningTime.min,&r[i].runningTime.sec);      
  for(int j=0;j<racer;j++)
  {
    if((r[j].runningTime.min<r[j+1].runningTime.min)&&(r[j].runningTime.sec<r[j+1].runningTime.sec))
    {
      R=r[j].runningTime.min;
      T=r[j].runningTime.sec;
    }  
  }
  
   printf("firstname:%slastname:%s\n",r[T].firstname,r[T].lastname);
  if((R<r[j].record->min)&&(T<r[j].record->sec))
   printf("he/she is able to break his/her own record.\n");
  else
   printf("he/she is not able to break his/her own record\n");
  for(int j=0;j<racer;j++)
  {
   if(R<r[j].record)
     S=R;
     Y=j;
  } 
   if(S<r[Y].record) 
    printf("he/she is able to break others record\n");
   else
    printf("he/she is not able to break others record");

  printf("firstname:\t\tlastname:\t\tID:\t\trecord:\t\trunningTime:\t\t\n");
  while(j<racer) 
   {
     for(int j=0;j<racer;j++)
   {
      if((r[j].runningTime.min<r[j+1].runningTime.min)&&(r[j].runningTime.sec<r[j+1].runningTime.sec))
      {
       R=r[j].runningTime.min;
       T=r[j].runningTime.sec;
      }    
   }  
      printf("%s %s %s %d %d %d %d\n",r[j].firstname,r[j].lastname,
      r[j].ID,(*r).record->min,(*r).record->sec,r[j].runningTime.min,r[j].runningTime.sec);
      R=1000;
      T=1000;
    
   }

}